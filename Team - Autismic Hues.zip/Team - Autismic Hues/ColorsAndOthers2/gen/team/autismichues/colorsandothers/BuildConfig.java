/** Automatically generated file. DO NOT MODIFY */
package team.autismichues.colorsandothers;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}