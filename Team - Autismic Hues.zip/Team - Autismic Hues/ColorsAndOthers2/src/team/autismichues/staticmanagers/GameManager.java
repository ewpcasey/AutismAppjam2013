package team.autismichues.staticmanagers;

public class GameManager extends StaticManager {

	private static GameManager instance;
	private int currentScore = 0;
	private int totalQuestions = 0;

	public static GameManager getInstance() {
		instance = new GameManager();
		return instance;
	}

	public void setupManager() {

	}

	public void resetManager() {
		this.currentScore = 0;
		this.totalQuestions = 0;
	}

	public int getTotalQuestions() {
		return this.totalQuestions;

	}

	public void incrementTotalQuestions() {
		++this.totalQuestions;
	}

	public int increaseScore() {
		return ++this.currentScore;
	}

	public int getScore() {
		return this.currentScore;
	}

	public static GameManager getManager() {
		return instance;
	}

}
