package team.autismichues.staticmanagers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import team.autismichues.colorsandothers.R;
import team.autismichues.flashcard.Flashcard;

public class FlashcardManager extends StaticManager {

	// This class has a static instance. To properly access the methods within this class,
	// use "FlashcardManager.getManager()..." This should mostly be used for local, small
	// files because of Android's limited memory

	private static FlashcardManager instance = new FlashcardManager();
	private static ArrayList<Flashcard> flashcardStorage = new ArrayList<Flashcard>();
	private Random random = new Random();

	public void setupManager() {
		flashcardStorage.add(new Flashcard(R.drawable.black,"Black", "Which button is black?"));
		flashcardStorage.add(new Flashcard(R.drawable.blue,"Blue", "Which button is blue?"));
		flashcardStorage.add(new Flashcard(R.drawable.brown,"Brown", "Which button is brown?"));
		flashcardStorage.add(new Flashcard(R.drawable.green,"Green", "Which button is green?"));
		flashcardStorage.add(new Flashcard(R.drawable.orange,"Orange", "Which button is orange?"));
		flashcardStorage.add(new Flashcard(R.drawable.pink,"Pink", "Which button is pink?"));
		flashcardStorage.add(new Flashcard(R.drawable.purple,"Purple", "Which button is purple?"));
		flashcardStorage.add(new Flashcard(R.drawable.red,"Red", "Which button is red?"));
		flashcardStorage.add(new Flashcard(R.drawable.white,"White", "Which button is white?"));
		flashcardStorage.add(new Flashcard(R.drawable.yellow,"Yellow", "Which button is yellow?"));
	}

	public void resetManager() {
		flashcardStorage = new ArrayList<Flashcard>();
		setupManager();
	}

	public Flashcard getFlashcard(int imageID) {
		System.out.println("Attempting to get flashcard with ID: " + imageID);
		for(Flashcard current : flashcardStorage) {
			if(current.getImageID()==imageID) {
				System.out.println("Id match found!: " + current.getImageID() + " == " + imageID);
				return current;
			}
		}
		return null;
	}

	// Add a flashcard to storage
	public void addFlashcard(int imageId, String imageName, String question) {
		flashcardStorage.add(new Flashcard(imageId,imageName,question));
	}

	// Get a random flashcard array with a specified size (this allows for possible
	// expansion in the future
	public ArrayList<Flashcard> getRandomFlashcards(int size, int exemptID) {
		ArrayList<Flashcard> toReturn = new ArrayList<Flashcard>();
		ArrayList<Integer>   usedIndices = new ArrayList<Integer>();
		
		while(toReturn.size()<size) {
			int currentRandom = random.nextInt(this.flashcardStorage.size()-1);
			if(!usedIndices.contains(currentRandom)&&this.flashcardStorage.get(currentRandom).getImageID()!=exemptID) {
				usedIndices.add(currentRandom);
				toReturn.add(this.flashcardStorage.get(currentRandom));
			}
		}
		
		return toReturn;
	}

	public ArrayList<Flashcard> getAllCards(){
		return flashcardStorage;
	}

	public static FlashcardManager getManager() {
		return instance;
	}
}
