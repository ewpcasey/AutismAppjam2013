package team.autismichues.staticmanagers;

public abstract class StaticManager {

	// This class defines what StaticManager is supposed to have
	// 1. getManager() returns the static instance of this class
	// 2. resetManager() is used while the application is running,
	//    and may be used to clear values stored within the class
	
	private static StaticManager instance;
	
	public static StaticManager getManager() {
		return instance;
	}
	
	public abstract void resetManager();
	
	
}
