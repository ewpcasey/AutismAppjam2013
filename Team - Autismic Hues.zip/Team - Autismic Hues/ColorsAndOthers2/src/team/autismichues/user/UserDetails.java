package team.autismichues.user;

public class UserDetails {

	public static String username, email, password, fullname, parentemail;
	
}
