package team.autismichues.flashcard;

public class Flashcard {

	private int imageId;
	private String question;
	private String imageName;

	public Flashcard(int imageId, String imageName, String question) {
		this.imageId = imageId;
		this.imageName = imageName;
		this.question = question;
	}
	
	public int getImageID() {return this.imageId;}
	public String getQuestion() {return this.question;}
	public String getImageName(){
		return this.imageName;
	}
	
	public String toString() {
		return this.imageId + " " + "imageName";
	}
}
