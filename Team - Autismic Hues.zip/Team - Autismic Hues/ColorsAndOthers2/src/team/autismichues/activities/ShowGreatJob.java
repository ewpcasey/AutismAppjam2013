package team.autismichues.activities;

import team.autismichues.colorsandothers.R;
import team.autismichues.colorsandothers.R.layout;
import team.autismichues.colorsandothers.R.menu;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class ShowGreatJob extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showgreatjob);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show_great_job, menu);
		return true;
	}

}
