package team.autismichues.activities;

import team.autismichues.colorsandothers.R;
import team.autismichues.colorsandothers.R.layout;
import team.autismichues.colorsandothers.R.menu;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class GreatGameScreenOnly extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.greatgamescreenonly);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.great_game_screen_only, menu);
		return true;
	}

}
