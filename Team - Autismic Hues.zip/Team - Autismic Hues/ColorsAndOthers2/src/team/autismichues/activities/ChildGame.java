package team.autismichues.activities;

import http.interfac.ServerInterface;

import java.util.ArrayList;
import java.util.Collections;

import team.autismichues.colorsandothers.R;
import team.autismichues.flashcard.Flashcard;
import team.autismichues.staticmanagers.FlashcardManager;
import team.autismichues.staticmanagers.GameManager;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageButton;
import android.widget.TextView;

public class ChildGame extends Activity {

	private static ImageButton imageButtonOne, imageButtonTwo,
			imageButtonThree, imageButtonFour, masterButton;
	private static TextView questionText;
	private static ArrayList<Flashcard> flashcards = new ArrayList<Flashcard>();
	public static Flashcard masterFlashcard;
	private int incorrectID = 0;
	Animation animation;
	
	public static GameManager scoreManager;
	
	// private final Animation animation = AnimationUtils.loadAnimation(this,
	// R.anim.anim_alpha);
	private final Runnable mUpdateUITimerTask = new Runnable() {
		public void run() {
			questionText.setText(questionToDisplay);
			imageButtonOne.setImageDrawable(getResources().getDrawable(idOne));
			imageButtonTwo.setImageDrawable(getResources().getDrawable(idTwo));
			imageButtonThree.setImageDrawable(getResources().getDrawable(
					idThree));
			imageButtonFour
					.setImageDrawable(getResources().getDrawable(idFour));
			mHandler.postDelayed(mUpdateUITimerTask, 1000);
		}
	};
	private Handler mHandler = new Handler();

	private static String questionToDisplay = "Screen Locked";
	private static int idOne = R.drawable.ic_launcher;
	private static int idTwo = R.drawable.ic_launcher;
	private static int idThree = R.drawable.ic_launcher;
	private static int idFour = R.drawable.ic_launcher;
	private static boolean canClick = false;

	// @Override
	// protected void onPause() {
	// mHandler.removeCallbacks(mUpdateUITimerTask);
	// }
	//
	// @Override
	// protected void onResume() {
	// mHandler = new Handler();
	// }
	//
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.childgame);

		// Set references for button and text
		imageButtonOne = (ImageButton) findViewById(R.id.imageButton1);
		imageButtonTwo = (ImageButton) findViewById(R.id.imageButton2);
		imageButtonThree = (ImageButton) findViewById(R.id.imageButton3);
		imageButtonFour = (ImageButton) findViewById(R.id.imageButton4);
		questionText = (TextView) findViewById(R.id.questionText);

		// Set initial text
		questionText.setText("Loading...");

		// animation settings
		animation = new AlphaAnimation(1, 0);
		animation.setDuration(300);
		animation.setInterpolator(new LinearInterpolator());
		animation.setRepeatCount(Animation.INFINITE);
		animation.setRepeatMode(Animation.REVERSE);

		// Start runnable
		mHandler.postDelayed(mUpdateUITimerTask, 1000);

		// Set great job image to invisible
		setMasterButton();
		
		//
		
		// Setup listeners
		imageButtonOne.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!canClick || !flashcards.get(0).equals(masterFlashcard)) {
					incorrectID = flashcards.get(0).getImageID();
					flashButton();
					new syncIncorrect().execute((Object) null);
				} else {
					invokeGreatJob();
					new syncCorrect().execute((Object) null);
				}
			}
		});

		imageButtonTwo.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!canClick || !flashcards.get(1).equals(masterFlashcard)) {
					incorrectID = flashcards.get(1).getImageID();
					flashButton();
					new syncIncorrect().execute((Object) null);
				} else {
					invokeGreatJob();
					new syncCorrect().execute((Object) null);
				}

			}
		});

		imageButtonThree.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!canClick || !flashcards.get(2).equals(masterFlashcard)) {
					incorrectID = flashcards.get(2).getImageID();
					flashButton();
					new syncIncorrect().execute((Object) null);
				} else {
					invokeGreatJob();
					new syncCorrect().execute((Object) null);
				}

			}
		});

		imageButtonFour.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!canClick || !flashcards.get(3).equals(masterFlashcard)) {
					incorrectID = flashcards.get(3).getImageID();
					flashButton();
					new syncIncorrect().execute((Object) null);
				} else {
					invokeGreatJob();
					new syncCorrect().execute((Object) null);
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.child_game, menu);
		return true;
	}

	public static void createNextGameScreen(int id) {
		flashcards = new ArrayList<Flashcard>();
		flashcards.add(masterFlashcard = FlashcardManager.getManager()
				.getFlashcard(id));
		flashcards.addAll(FlashcardManager.getManager().getRandomFlashcards(3, masterFlashcard.getImageID()));
		questionToDisplay = masterFlashcard.getQuestion();
		Collections.shuffle(flashcards);
		idOne = flashcards.get(0).getImageID();
		idTwo = flashcards.get(1).getImageID();
		idThree = flashcards.get(2).getImageID();
		idFour = flashcards.get(3).getImageID();
		canClick = true;
		System.out.println(flashcards.toString());
	}

	private void invokeCorrectAnswer() {
		Intent intent = new Intent(ChildGame.this, ShowChildCorrectAnswer.class);
		startActivity(intent);
	}

	private void invokeGreatJob() {
		scoreManager.increaseScore();
		scoreManager.incrementTotalQuestions();
		Intent intent = new Intent(ChildGame.this, ShowGreatJob.class);
		startActivity(intent);
	}

	private void setMasterButton() {
		if (masterFlashcard.getImageID() == idOne)
			masterButton = imageButtonOne;
		else if (masterFlashcard.getImageID() == idTwo)
			masterButton = imageButtonTwo;
		else if (masterFlashcard.getImageID() == idThree)
			masterButton = imageButtonThree;
		else if (masterFlashcard.getImageID() == idFour)
			masterButton = imageButtonFour;

	}
	
	private void flashButton()
	{
		scoreManager.incrementTotalQuestions();
		final Handler handler = new Handler();
		masterButton.startAnimation(animation);
		Runnable runFlash = null;
		handler.postDelayed(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				invokeCorrectAnswer();
			}
			
		},3000);
	}

	private class syncIncorrect extends AsyncTask {

		@Override
		protected Object doInBackground(Object... params) {
			ServerInterface.sendInCorrectAnswerResponse(incorrectID);
			return null;
		}

	}

	private class syncCorrect extends AsyncTask {

		@Override
		protected Object doInBackground(Object... params) {
			ServerInterface.sendCorrectAnswerResponse();
			return null;
		}

	}
}