package team.autismichues.activities;

import team.autismichues.colorsandothers.R;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.widget.ImageView;

public class ShowChildCorrectAnswer extends Activity {
	ImageView iv;
	private Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showchildcorrectanswer);
		iv = (ImageView) findViewById(R.id.CorrectImage);
		iv.setImageDrawable(getResources().getDrawable(
				ChildGame.masterFlashcard.getImageID()));

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show_child_correct_answer, menu);
		return true;
	}

}
