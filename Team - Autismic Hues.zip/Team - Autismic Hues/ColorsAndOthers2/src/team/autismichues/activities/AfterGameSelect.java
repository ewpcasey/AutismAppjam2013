package team.autismichues.activities;

import http.interfac.ServerInterface;
import team.autismichues.colorsandothers.R;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AfterGameSelect extends Activity {
	Button ready;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aftergameselect);
		ready = (Button) findViewById(R.id.readyButton);
		ready.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new sync().execute((Object) null);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.after_game_select, menu);
		return true;
	}
	private class sync extends AsyncTask {
		@Override
		protected Object doInBackground(Object... params) {
			ServerInterface.sendGameAcceptanceToParent();
			return null;
		}
		protected void onPostExecute(Object obres) {
		}
	}
}
