package team.autismichues.activities.parent;

import http.interfac.ServerInterface;
import team.autismichues.colorsandothers.R;
import team.autismichues.flashcard.Flashcard;
import team.autismichues.staticmanagers.FlashcardManager;
import team.autismichues.user.UserDetails;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;

public class ColorGame extends Activity {

	private Button blackButton, blueButton, brownButton, greenButton,
			orangeButton, pinkButton, purpButton, redButton, whiteButton,
			endButton = null;
	private RelativeLayout loadingPop = null;
	private boolean canClick;
	public static boolean childSuccess = false;
	public static String WRONGANSWER = null;
	AlertDialog.Builder alertIncorrect = null;
	boolean showChildAnswer = true;

	private final Runnable mUpdateUITimerTask = new Runnable() {
		public void run() {
			System.out.println("This is running!");
			if (!isFinishing()) {
				if (!canClick && WRONGANSWER != null
						&& WRONGANSWER.trim().length() > 0) {
					if (showChildAnswer) {
						FlashcardManager fMngr = new FlashcardManager();
						Flashcard colorName = fMngr.getFlashcard(Integer
								.parseInt(WRONGANSWER.trim()));
						String name = colorName.getImageName();
						callAlertIncorrect(name);
						showChildAnswer = false;
					}
					showChildAnswer = true;
					WRONGANSWER = null;
				} else if (!canClick && childSuccess) {
					if (showChildAnswer) {
						callAlertCorrect();
						showChildAnswer = false;
					}
					showChildAnswer = true;
					childSuccess = false;
				} else if (canClick)
					loadingPop.setVisibility(View.GONE);
				else if (!canClick) {
					loadingPop.setVisibility(View.VISIBLE);
				}

				mHandler.postDelayed(mUpdateUITimerTask, 1000);
			}
		}
	};
	private Handler mHandler = new Handler();
	private Handler wHandler = new Handler();

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.colorgame);
		// Can the user interact with the UI?
		canClick = true;

		// Loading screen (Turns that ish off)
		loadingPop = (RelativeLayout) findViewById(R.id.loadingParent);
		loadingPop.setVisibility(View.GONE);

		// Setup the Runnable Handler
		mHandler.postDelayed(mUpdateUITimerTask, 1000);
		// Setup button references
		blackButton = (Button) findViewById(R.id.parBlack);
		blueButton = (Button) findViewById(R.id.parBlue);
		brownButton = (Button) findViewById(R.id.parBrown);
		greenButton = (Button) findViewById(R.id.parGreen);
		orangeButton = (Button) findViewById(R.id.parOrange);
		pinkButton = (Button) findViewById(R.id.parPink);
		purpButton = (Button) findViewById(R.id.parPurp);
		redButton = (Button) findViewById(R.id.parRed);
		whiteButton = (Button) findViewById(R.id.parWhite);
		endButton = (Button) findViewById(R.id.endSessionButton);

		// Setup listeners for buttons
		blackButton.setOnClickListener(onclick);
		blueButton.setOnClickListener(onclick);
		brownButton.setOnClickListener(onclick);
		greenButton.setOnClickListener(onclick);
		orangeButton.setOnClickListener(onclick);
		pinkButton.setOnClickListener(onclick);
		purpButton.setOnClickListener(onclick);
		redButton.setOnClickListener(onclick);
		whiteButton.setOnClickListener(onclick);
		endButton.setOnClickListener(onclick);
	}

	// This method should only be called if there's an actual response

	private OnClickListener onclick = new View.OnClickListener() {

		public void onClick(View v) {
			if (canClick) {
				switch (v.getId()) {
				case R.id.parBlack:
					new syncBlack().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parBlue:
					new syncBlue().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parBrown:
					new syncBrown().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parGreen:
					new syncGreen().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parOrange:
					new syncOrange().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parPink:
					new syncPink().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parPurp:
					new syncPurp().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parRed:
					new syncRed().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.parWhite:
					new syncWhite().execute((Object) null);
					waitForChildResponse();
					break;
				case R.id.endSessionButton:
					new syncEndOfGame().execute((Object) null);
					waitForChildResponse();
					break;

				}
			}
		}
	};

	private void callAlertIncorrect(String incorrect) {
		AlertDialog.Builder alertIncorrect = new AlertDialog.Builder(
				ColorGame.this);
		alertIncorrect.setTitle("Incorrect Answer From Child");
		alertIncorrect.setMessage("Your child selected: " + incorrect);
		alertIncorrect.setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						canClick = true;

					}
				});

		AlertDialog ad = alertIncorrect.create();
		ad.show();
	}

	private void callAlertCorrect() {
		AlertDialog.Builder alertCorrect = new AlertDialog.Builder(
				ColorGame.this);
		alertCorrect.setTitle("Correct Answer From Child!");
		alertCorrect
				.setMessage("Your child has selected the correct answer. Please choose the next question.");
		alertCorrect.setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						canClick = true;
					}
				});
		AlertDialog da = alertCorrect.create();
		da.show();

	}

	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.color_game, menu);
		return true;
	}

	// Display a waiting screen so the paren't cannot press additional buttons
	// and possible confuse the child client
	public void waitForChildResponse() {
		canClick = false;
	}

	// Send Events
	private class syncBlack extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.black);
			return null;
		}
	}

	private class syncBlue extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.blue);
			return null;
		}
	}

	private class syncBrown extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.brown);
			return null;
		}

	}

	private class syncGreen extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.green);
			return null;
		}

	}

	private class syncOrange extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.orange);
			return null;
		}
	}

	private class syncPink extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.pink);
			return null;
		}

	}

	private class syncPurp extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.purple);
			return null;
		}

	}

	private class syncRed extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.red);
			return null;
		}

	}

	private class syncWhite extends AsyncTask {
		protected Object doInBackground(Object... params) {
			ServerInterface.sendQuestionToTheKid(R.drawable.white);
			return null;
		}

	}

	private class syncEndOfGame extends AsyncTask {

		@Override
		protected Object doInBackground(Object... params) {
			// TODO Auto-generated method stub
			ServerInterface.sendEndOfGameToChild();
			return null;
		}

	}

}
