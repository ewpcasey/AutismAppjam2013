package team.autismichues.activities.parent;

import http.interfac.ServerInterface;
import team.autismichues.colorsandothers.R;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class GameSelection extends  Activity{
	public static Button colors, others;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gameselection);
		colors = (Button) findViewById(R.id.Colors);
		others = (Button) findViewById(R.id.Others);
		colors.setOnClickListener(onclicklistener);
		others.setOnClickListener(onclicklistener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game_selection, menu);
		return true;
	}

	private OnClickListener onclicklistener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.Colors:
				new syncColors().execute((Object) null);	
			case R.id.Others:
				new syncOthers().execute((Object) null);	
			}
		}

	};

	private class syncColors extends AsyncTask {
		@Override
		protected Object doInBackground(Object... params) {
			ServerInterface.sendGameInfoToMyChild("Colors");
			return null;
		}
		protected void onPostExecute(Object obres) {
		}
	}

	private class syncOthers extends AsyncTask {
		@Override
		protected Object doInBackground(Object... params) {
			ServerInterface.sendGameInfoToMyChild("Others");
			return null;
		}
		protected void onPostExecute(Object obres) {
		}
	}
}
