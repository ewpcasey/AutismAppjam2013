package team.autismichues.activities.parent;

import team.autismichues.colorsandothers.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class ParentMenu extends Activity {

	private Button playButton, manageButton, marketButton;
	private ProgressBar progress;
	private ImageView iv;
	private RelativeLayout rl;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_parent);
		
		
		// Init buttons
		playButton = (Button) findViewById(R.id.parMenuPlay);
		manageButton = (Button) findViewById(R.id.parMenuManage);
		marketButton = (Button) findViewById(R.id.parMenuMarket);
		rl = (RelativeLayout) findViewById(R.id.waitingForChild);
		
		rl.setVisibility(View.GONE);
		playButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				rl.setVisibility(View.VISIBLE);
				playButton.setEnabled(false);
			}
			
		});
		manageButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				alert();
			}
			
		});;
		marketButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				alert();
			}
			
		});;
	}
	
	private void alert() {
		AlertDialog.Builder alertCorrect = new AlertDialog.Builder(ParentMenu.this);
		alertCorrect.setTitle("Feature Unavailable");
		alertCorrect
				.setMessage("This feature is unavailable at this time.");
		alertCorrect.setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
					}
				});
		AlertDialog da = alertCorrect.create();
		da.show();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.parent_menu, menu);
		return true;
	}

}
