package team.autismichues.activities.parent;

import http.interfac.ServerInterface;
import AppConstants.AppConstants;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import team.autismichues.activities.AfterGameSelect;
import team.autismichues.activities.ChildGame;
import team.autismichues.activities.EndofGame;
import team.autismichues.activities.MainActivity;
import team.autismichues.activities.RegistrationSuccess;
import team.autismichues.activities.SendScores;
import team.autismichues.activities.ShowChildCorrectAnswer;
import team.autismichues.colorsandothers.R;
import team.autismichues.user.UserDetails;

public class Login extends Activity {
	private EditText etUsername, etPassword;
	private Button loginParent;
	private CheckBox isKid;
	static private boolean replay = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		initializeRegister();

		etUsername = (EditText) findViewById(R.id.loginUsername);
		etPassword = (EditText) findViewById(R.id.loginPassword);
		loginParent = (Button) findViewById(R.id.btnLogin);

		loginParent.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				loginParent.setPressed(true);
				UserDetails.username = etUsername.getText().toString();
				UserDetails.password = etPassword.getText().toString();
				sendMessage(v);

			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	Intent intent = null;

	public void sendMessage(View view) {
		
		System.out
				.println("[User] :  Send button request received. Connecting to server...");
		intent = new Intent(Login.this, ParentMenu.class);
		new sync().execute((Object) null);
		
	}

	private class sync extends AsyncTask {

		@Override
		protected Object doInBackground(Object... params) {
			String message = ServerInterface.logIn(UserDetails.username,
					UserDetails.password, "no");
			
			if(message.contains("welcome")){
				
				Thread serverResponseThread = new Thread(){
					
					
					public void run(){

						AppConstants K = new AppConstants();
						while (true) {
							String response = ServerInterface.getResponseViaPolling();
							if (response == "") {

								// If no response received from System, wait for 400 ms and
								// continue
								try {
									Thread.sleep(1000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								continue;
							}

							// Process the response for the desired UI
							// Response format --> "Event, Message"
							// Display the Message in the screen based on Event

							String[] responseArr = response.split(",");
							String eventName = responseArr[0];
							String responseMessage = responseArr[1];
							Intent intent = null;
							
							// Create a new intent (new screen) for parent to prompt for game
							// select as Kid has joined the game.
							if (eventName.equals(K.CHILD_LOGGED_IN_SUCCESS)) {
								System.out.println("Success");
								 intent = new Intent(Login.this, GameSelection.class);
								intent.putExtra(eventName, responseMessage);
								startActivity(intent);
							}
					          // Create a new intent (new screen) for Parent to display the
                            // game start".
                            else if (eventName.equalsIgnoreCase(K.CHILD_GAME_ACCEPTANCE)) {
                            		intent = new Intent(Login.this, ColorGame.class);
                            		intent.putExtra(eventName, responseMessage);
                            		startActivity(intent);
                          
                                
                            }
							// Create a new intent (new screen) for parent to show if Kid has
							// answered the question correctly.
							else if (eventName.equalsIgnoreCase(K.CHILD_ANSWER_CORRECT)) {
//								 intent = new Intent(Login.this, AnswerCorrect.class);
//									intent.putExtra(eventName, responseMessage);
//									startActivity(intent);
								ColorGame.childSuccess = true;
							}
							// Create a new intent (new screen) for parent to show if Kid has
							// answered the question in-correctly.
							else if (eventName.equalsIgnoreCase(K.CHILD_ANSWER_INCORRECT)) {

								ColorGame.WRONGANSWER = responseMessage;
							}
							// Create a new intent (new screen) for parent to display the kid's
							// score.
							else if (eventName.equalsIgnoreCase(K.SEND_SCORE)) {
								 intent = new Intent(Login.this, SendScores.class);
									intent.putExtra(eventName, responseMessage);
									SendScores.scoreString = responseMessage;
									startActivity(intent);
							}
									
							else if(eventName.equalsIgnoreCase(K.CHILD_DENY_PLAY)){
								SendScores.kidDenies = true;
							}
							//Game replay acceptance to parent ...redirect to colors and other screen
							else if (eventName.equalsIgnoreCase(K.REPLAY_ACCEPTANCE)){
								intent = new Intent (Login.this, GameSelection.class);
								intent.putExtra(eventName, responseMessage);
                        		startActivity(intent);
							}
														// Create a new intent (new screen) for Kid to display the
							// "Hey XXXX, get ready for playing YYYY".
//							else if (eventName.equalsIgnoreCase(K.GAME_SELECT_BY_PARENT)) {
//								intent = new Intent(Login.this, AfterGameSelect.class);
//								intent.putExtra(eventName, responseMessage);
//								startActivity(intent);
//							}
							// Create intent (new screen) for kid to display the question
//							else if (eventName.equalsIgnoreCase(K.PROMPT_QUESTION_AT_CHILD)) {
//								 intent = new Intent(Login.this, ChildGame.class);
//									intent.putExtra(eventName, responseMessage);
//									startActivity(intent);
//									ChildGame.createNextGameScreen(ColorGame.flahsca);
//
//							}

							// Create a new intent (new screen) for Kid to show that game has
							// ended.
//							else if (eventName.equalsIgnoreCase(K.END_OF_GAME_BY_PARENT)) {
//								 intent = new Intent(Login.this, EndofGame.class);
//									intent.putExtra(eventName, responseMessage);
//									startActivity(intent);
//
//							}
							// Do a gentle polling.
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
					
					}
					
				};
				
				serverResponseThread.start();
				
			}
			
			return message;
		}

		protected void onPostExecute(Object obres) {
			String result = (String) obres;
			System.out.println("[User] response from server :: " + result);
			intent.putExtra(MainActivity.EXTRA_MESSAGE, result);
			startActivity(intent);
		}

	}

	private void initializeRegister() {
		TextView registerScreen = (TextView) findViewById(R.id.btnLinkToRegisterScreen);
		registerScreen.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// Switching to Register screen
				Intent i = new Intent(Login.this,
						MainActivity.class);
				startActivity(i);
				finish();
			}
		});
	}

}
