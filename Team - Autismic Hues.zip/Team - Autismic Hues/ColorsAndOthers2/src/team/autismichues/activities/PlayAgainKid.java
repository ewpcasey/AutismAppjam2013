package team.autismichues.activities;

import http.interfac.ServerInterface;
import team.autismichues.colorsandothers.R;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class PlayAgainKid extends Activity {
	Button yes, no;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.playagain);
		
		yes = (Button) findViewById(R.id.YesButton);
		no = (Button) findViewById(R.id.NoButton);
		
		yes.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new syncPlayAgain().execute((Object) null);
			}
		});
		
		no.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new syncDontPlayAgain().execute((Object) null);
				Intent intent = new Intent(PlayAgainKid.this, EndofGame.class);
				startActivity(intent);
				
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.play_again_kid, menu);
		return true;
	}
	
	private class syncPlayAgain extends AsyncTask{

		@Override
		protected Object doInBackground(Object... params) {
			// TODO Auto-generated method stub
			ServerInterface.sendReplayAcceptanceToParent();
			return null;
		}
		
	}
	private class syncDontPlayAgain extends AsyncTask{

		@Override
		protected Object doInBackground(Object... params) {
			// TODO Auto-generated method stub
			ServerInterface.sendChildDenyResponse();
			return null;
		}
		
	}

}
