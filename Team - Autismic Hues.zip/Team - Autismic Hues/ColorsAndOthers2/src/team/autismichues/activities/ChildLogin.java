package team.autismichues.activities;

import http.interfac.ServerInterface;
import AppConstants.AppConstants;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import team.autismichues.activities.parent.ColorGame;
import team.autismichues.activities.parent.GameSelection;
import team.autismichues.activities.parent.Login;
import team.autismichues.colorsandothers.R;
import team.autismichues.staticmanagers.FlashcardManager;
import team.autismichues.staticmanagers.GameManager;
import team.autismichues.user.UserDetails;

public class ChildLogin extends Activity {

	private EditText etusername;
	private Button cLogin;
	private static String EXTRA_MESSAGE = "1";
	private Intent intent = null;
	String username;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.child);

		// FLASHCARD MANAGER START
		FlashcardManager.getManager().setupManager();

		parentLogin();
		cLogin = (Button) findViewById(R.id.childLoginButton);
		etusername = (EditText) findViewById(R.id.childUsername);
		UserDetails.username = etusername.getText().toString();
		username = UserDetails.username;
		
		cLogin.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				UserDetails.username = etusername.getText().toString();

				sendMessage(v);
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.child_login, menu);
		return true;
	}

	public void sendMessage(View view) {

		System.out.println("[User] : Send button request received. Connecting to server...");
		intent = new Intent(ChildLogin.this, ChildMenu.class);
		new sync().execute((Object) null);
	}

	private void parentLogin() {
		TextView parentLog = (TextView) findViewById(R.id.ParentButton);
		parentLog.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(ChildLogin.this, Login.class);
				startActivity(i);
				finish();
			}
		});
	}

	@SuppressWarnings("rawtypes")
	public class sync extends AsyncTask {

		@Override
		protected Object doInBackground(Object... params) {
			// TODO Auto-generated method stub
			String message = ServerInterface.logIn(UserDetails.username, "", "yes");

			if(message.contains("welcome")){

				Thread serverResponseThread = new Thread(){


					public void run(){
						AppConstants K = new AppConstants();
						while (true) {
							String response = ServerInterface.getResponseViaPolling();
							if (response == "") {

								// If no response received from System, wait for 400 ms and
								// continue
								try {
									Thread.sleep(1000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								continue;
							}

							// Process the response for the desired UI
							// Response format --> "Event, Message"
							// Display the Message in the screen based on Event

							String[] responseArr = response.split(",");
							String eventName = responseArr[0];
							String responseMessage = responseArr[1];
							Intent intent = null;

							// RECEIVING EVENTS
							if (eventName.equalsIgnoreCase(K.GAME_SELECT_BY_PARENT)) {
								ChildGame.scoreManager = GameManager.getInstance();
								intent = new Intent(ChildLogin.this, AfterGameSelect.class);
								intent.putExtra(eventName, responseMessage);
								startActivity(intent);
							}
							// Create intent (new screen) for kid to display the question
							else if (eventName.equalsIgnoreCase(K.PROMPT_QUESTION_AT_CHILD)) {
								intent = new Intent(ChildLogin.this, ChildGame.class);
								intent.putExtra(eventName, responseMessage);
								startActivity(intent);
								ChildGame.createNextGameScreen(Integer.parseInt(responseMessage.trim()));
								System.out.println("PROMPT QUESTION AT CHILD EVENT RECEIVED: " + responseMessage);
							}
							// Create a new intent (new screen) for Kid to show that game has
							// ended.
							else if (eventName.equalsIgnoreCase(K.END_OF_GAME_BY_PARENT)) {
								
								intent = new Intent(ChildLogin.this, GreatGameScreenOnly.class);
								intent.putExtra(eventName, responseMessage);
								startActivity(intent);
								new syncScore().execute((Object) null);
							}
							else if (eventName.equalsIgnoreCase(K.REPLAY_REQUEST))
							{
								intent = new Intent(ChildLogin.this, PlayAgainKid.class);
								startActivity(intent);
							}
							
							// Create new intent for Kid to go back to login screen
							else if(eventName.equalsIgnoreCase(K.PARENT_EXIT)){
								
											intent = new Intent(ChildLogin.this, EndofGame.class);
											startActivity(intent);
							}
							// Create a new intent (new screen) for parent to prompt for game
							// select as Kid has joined the game.
							//								if (eventName.equals(K.CHILD_LOGGED_IN_SUCCESS)) {
							//									 intent = new Intent(ChildLogin.this, GameSelection.class);
							//									intent.putExtra(eventName, responseMessage);
							//									startActivity(intent);
							//								}

							// Create a new intent (new screen) for Kid to display the
							// "Hey XXXX, get ready for playing YYYY".
							// Create a new intent (new screen) for Parent to display the
							// game start".
							//	                            else if (eventName.equalsIgnoreCase(K.CHILD_GAME_ACCEPTANCE)) {
							//	                            	
							//	                            	intent = new Intent(ChildLogin.this, ColorGame.class);
							//	                            	intent.putExtra(eventName, responseMessage);
							//	                            	startActivity(intent);
							//	                                
							//	                            }
							// Create a new intent (new screen) for parent to show if Kid has
							// answered the question correctly.
							//								else if (eventName.equalsIgnoreCase(K.CHILD_ANSWER_CORRECT)) {
							//									 intent = new Intent(ChildLogin.this, AnswerCorrect.class);
							//										intent.putExtra(eventName, responseMessage);
							//										startActivity(intent);
							//								}

							// Create a new intent (new screen) for parent to show if Kid has
							// answered the question in-correctly.
							//								else if (eventName.equalsIgnoreCase(K.CHILD_ANSWER_INCORRECT)) {
							//									 intent = new Intent(ChildLogin.this, AnswerInccorect.class);
							//										intent.putExtra(eventName, responseMessage);
							//										startActivity(intent);
							//								}
							// Create a new intent (new screen) for parent to display the kid's
							// score.
							//								else if (eventName.equalsIgnoreCase(K.SEND_SCORE)) {
							//									 intent = new Intent(ChildLogin.this, SendScores.class);
							//										intent.putExtra(eventName, responseMessage);
							//										startActivity(intent);
							//								}

							// Do a gentle polling.
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}

					}

				};

				serverResponseThread.start();

			}

			return message;
		}

		protected void onPostExecute(Object obres) {
			String result = (String) obres;
			System.out.println("[User] response from server :: " + result);
			intent.putExtra(MainActivity.EXTRA_MESSAGE, result);
			startActivity(intent);
		}


	}
	
	private class syncScore extends AsyncTask{

		@Override
		protected Object doInBackground(
				Object... params) {
			// TODO Auto-generated method stub
			String score = UserDetails.username + " has got " + ChildGame.scoreManager.getScore() + " out of " + ChildGame.scoreManager.getTotalQuestions() + " questions right.";
			ServerInterface.sendChildScore(score);
			return null;
		}
		
	}


}
