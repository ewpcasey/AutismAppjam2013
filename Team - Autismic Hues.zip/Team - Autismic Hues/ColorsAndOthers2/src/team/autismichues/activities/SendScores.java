package team.autismichues.activities;

import http.interfac.ServerInterface;
import team.autismichues.activities.parent.Login;
import team.autismichues.colorsandothers.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class SendScores extends Activity {
	Button replay, endGame;
	public static String scoreString = null;
	public static boolean kidDenies = false;
	private Handler handler = new Handler();
	boolean showAgain = false;

	private final Runnable runDenial = new Runnable() {
		public void run() {
			if (!isFinishing()) {
				if (kidDenies && !showAgain) {
					kidDeniesPlay();
					showAgain = true;
				}

				handler.postDelayed(runDenial, 1000);
			}
		}

	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sendscores);
		
		kidDenies = false;
		replay = (Button) findViewById(R.id.ReplayButton);
		endGame = (Button) findViewById(R.id.EndGame);
		handler.postDelayed(runDenial, 1000);

		callAlertScore();
		replay.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new syncReplayForchild().execute((Object) null);
			}
		});

		endGame.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new syncEndGame().execute((Object) null);
				Intent i = new Intent(SendScores.this, Login.class);
				startActivity(i);
			}
		});
	}

	private class syncReplayForchild extends AsyncTask {
		@Override
		protected Object doInBackground(Object... params) {
			// TODO Auto-generated method stub
			ServerInterface.sendReplayRequest();

			return null;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.send_scores, menu);
		return true;
	}

	private void callAlertScore() {
		AlertDialog.Builder alertIncorrect = new AlertDialog.Builder(
				SendScores.this);
		alertIncorrect.setTitle("Score");
		alertIncorrect.setMessage(scoreString);
		alertIncorrect.setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						kidDenies = false;
					}
				});

		AlertDialog ad = alertIncorrect.create();
		ad.show();
	}

	private class syncEndGame extends AsyncTask {

		@Override
		protected Object doInBackground(Object... params) {
			// TODO Auto-generated method stub
			ServerInterface.sendParentExitToChild();
			return null;
		}

	}

	private void kidDeniesPlay() {
		AlertDialog.Builder alertIncorrect = new AlertDialog.Builder(
				SendScores.this);
		alertIncorrect.setTitle("No more!");
		alertIncorrect
				.setMessage("Sorry, your child has decided to end the game");
		alertIncorrect.setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(SendScores.this, Login.class);
						startActivity(intent);
					}
				});

		AlertDialog ad = alertIncorrect.create();
		ad.show();
	}

}
