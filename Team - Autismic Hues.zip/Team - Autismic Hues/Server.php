<?php
$con = mysqli_connect("localhost","sandboxe_app","appjam10","sandboxe_app");
if(mysqli_connect_errno($con)){
		echo "Error connecting to server";
}else{
	$command = $_REQUEST['command'];
	//Child & parent Registration 
	if($command == "register"){
			$name = $_REQUEST['name'];
			$username = $_REQUEST['username'];
			$pwd = $_REQUEST['pwd'];
			$isKid = $_REQUEST['isKid'];
			$kidEmail = $_REQUEST['kidEmail'];
			$parentEmail = $_REQUEST['parentEmail'];
			$result = mysqli_query($con, "DELETE FROM AAJ13_RESPONSE where `UserName` = '$username'");
			if($isKid == "yes"){
				$parentDetail = mysqli_query($con, "(select * from AAJ13_Users where UserEmail = '$parentEmail')");
				$row = mysqli_fetch_array($parentDetail);
				$parentUserName = $row['UserName'];
				//By commenting out the below lines, we make a user to register even if parent is not registered.
				//if($ParentUserName == ""){
					//echo "Parent not registered !!!";
				//}else{
				 $result = mysqli_query($con, "INSERT into AAJ13_Users (`Name`, `UserName`, `UserPwd`, `UserEmail`, `ParentUserName`, `SessionStatus`, `isKid`) values ('$name', '$username', '$pwd', '$kidEmail', '$parentUserName', '0', '1')");
				//} 
			}else{
				$result = mysqli_query($con, "INSERT into AAJ13_Users (`Name`, `UserName`, `UserPwd`, `UserEmail`, `ParentUserName`, `SessionStatus`, `isKid`) values ('$name', '$username', '$pwd', '$parentEmail', '', '0', '0')");
			}
			if($result == TRUE){
				echo "success";
			}else{
				echo "failure";
			}
	}
	
	//User log-in
	else if($command == "login"){
		$username = $_REQUEST['username'];
		$pwd = $_REQUEST['pwd'];
		$result = mysqli_query($con, "(select * from AAJ13_Users where UserName = '$username')");
		$row = mysqli_fetch_array($result);
		if($row == ''){
			echo "Invalid user.";
		}else{
			$name = $row['Name'];
			$isKid = $row['isKid'];
			if($isKid == '1'){
				$isSessionAlreadyActive = $row['SessionStatus'];
				if($isSessionAlreadyActive == '1'){
					echo "Dear '$name', you already have a game in play on another device. Please close you session and try again!";
				}else{
					echo "Dear '$name', welcome to Colors & Others.";
//					$result = mysqli_query($con, "Update AAJ13_Users set SessionStatus = '1' where UserName = '$username'");
				}
			}else{
				if($pwd == $row['UserPwd']){
					echo "Dear '$name', welcome to Colors & Others.";
//					$result = mysqli_query($con, "Update AAJ13_Users set SessionStatus = '1' where UserName = '$username'");
				}else{
					echo "Invalid user credentials, please try again.";
				}
			}
		}		
	}
	
	//Log-Out
	else if($command == "logout"){
		$username = $_REQUEST['username'];
		$result = mysqli_query($con, "Update AAJ13_Users set SessionStatus = '0' where UserName = '$username'");
		echo "Thanks for playing Colors and Others.";
	}
	
	//Send child log-in success to parent
	else if($command == "childLoginSuccess"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '''$username'' has logged-in successfully.')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}

	//Send Game name to my child
	else if($command == "sendGameNameToMyChild"){
		$username = $_REQUEST['username'];
		$gamename = $_REQUEST['gamename'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `ParentUserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$childname = $row['UserName'];
		$res = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$childname', '$event', 'hey ''$childname'', get ready to play ''$gamenam''')");
		if($res == TRUE){
			echo "Sucess";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}

	//Send child's game acceptance to parent
	else if($command == "sendGameAcceptanceToParent"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '...')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
	
	//Send question to kid's screen
	else if($command == "sendQuestion"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$imageid = $_REQUEST['imageid'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `ParentUserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$childname = $row['UserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$childname', '$event', '$imageid')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
	
	//Send child's correct answer response to parent
	else if($command == "sendCorrectAnsResponse"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}

	//Send child's in-correct answer response to parent
	else if($command == "sendInCorrectAnsResponse"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$answerchosen = $_REQUEST['answerchosen'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '$answerchosen')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
	
	//Send child's in-correct answer response to parent
	else if($command == "endOfGame"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `ParentUserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$childname = $row['UserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$childname', '$event', '')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
	
	//Send child's re-play request to child
	else if($command == "sendreplayrequest"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `ParentUserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$childname = $row['UserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$childname', '$event', '')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
	
	//Send child's deny request to child
	else if($command == "sendchilddenytoplay"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
	
	//Send parent exit request to child
	else if($command == "exit"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `ParentUserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$childname = $row['UserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$childname', '$event', '')");
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
		
	//Send child's score to parent
	else if($command == "sendScore"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$score = $_REQUEST['score'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '$score')");
		
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}
		
		//Send child's score to parent
	else if($command == "sendreplayacceptance"){
		$username = $_REQUEST['username'];
		$event = $_REQUEST['event'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_Users where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		$parentname = $row['ParentUserName'];
		$result = mysqli_query($con, "INSERT INTO AAJ13_RESPONSE values ('$parentname', '$event', '')");
		
		if($result == TRUE){
			echo "";
		}else{
			echo "Your response is not processed by server. Please try again.";
		}
	}

	
	
	//BackEnd polling job to retrive the response from other client
	else if($command == "getResponseViaPolling"){
		$username = $_REQUEST['username'];
		$result = mysqli_query($con, "(SELECT * FROM AAJ13_RESPONSE where `UserName` = '$username')");
		$row = mysqli_fetch_array($result);
		if($row == ''){
			echo "";
		}else{
			$result = mysqli_query($con, "DELETE FROM AAJ13_RESPONSE where `UserName` = '$username'");
			$event = $row['Event'];
			$message = $row['Message'];
			echo "$event, $message";
		}
	}
}
?>